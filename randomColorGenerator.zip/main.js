const container = document.querySelector('.container'),
btn = document.querySelector('#btn'),
showColorName = document.querySelector('#colorName');


let changeColor = () =>{
let letters = '123456789abcd';
let color ='#';
for(let i = 0; i <= 5; i++){
  color += letters[Math.floor(Math.random()*13)];
container.style.background = color;
showColorName.innerHTML = color;
showColorName.style.color = color;
}
btn.style.borderColor = color;
btn.style.color = color;

}

btn.addEventListener('click', ()=>{
  changeColor();
})

